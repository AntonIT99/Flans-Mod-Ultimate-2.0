Greylight Pack v3.0
by DerpiWolf.

Main thread: http://minecraft-smp.de/e107_plugins/forum/forum_viewtopic.php?42964.0
-----------------------------------------------------------------------------------

If you're reading this, thanks for actually reading it!

All models, items, graphics and configuration built by me. Any other assets not mentioned here are made by those credited.

If you would like to make suggestions or report bugs, do so on my main thread.

Please do not in any way, attempt to steal my work. Doing so will result in polite request. Or otherwise, threat of legal action.
(Most of the 900+ files actually have my name written in it, and some .class files forever having my name in it.)



-----------
PERMISSIONS
-----------
1. Distribution: 
You are allowed to use my pack for your personal, private or public use in a server. Distribution of my pack must be complete, with all files. 
Do not distribute with any further intentional wrapping of which inlcudes malicious installers. 
Do not remove any weapons, ammo, grenades or parts and attach them to another flansmod pack.

2. Pack Modification: 
Attributes and gun statistics may be edited for personal or server use. Item names may also be changed. Creating new texture skins and editing existing default texture skins are allowed.
You may disable/remove any weapons and items not appropiate to your personal or server use.



---------
CREDITING
---------
Crediting on my work is highly recommended.

Do not claim that the pack is made by you. This will be considered as plagarism, and will violate all existing terms.



-------
CONTACT
-------
Planet Minecraft - https://www.planetminecraft.com/member/derpiwolf



-------------
VERSION DATES
-------------
1.02.2015
- Alpha edition, v1.0.1
- Started work on version 1.1

25.02.2015
- Version 1.1

8.03.2015
- Version 1.1.2, three new guns.
- Started work on 1.2

20.03.2015
- Version 1.2

14.05.2015
- Version 1.3

23.07.2015
- Version 1.4

24.07.2015
- Version 1.4.1 Bugfixes.

28.09.2015
- Version 1.4.4 More bugfixes.

16.10.2015
- Version 1.4.5

30.3.2016
- Version 2.0

30.8.2016
- Version 2.0.3

1.10.2016
- Version 2.1

3.1.2018
- Version 2.9.5

11.03.2018
- Version 2.9.10, updated readme and patch notes.

30.03.2018
- Version 3.0, planet minecraft release.

---------
FOOTNOTES
---------
"The real question is, how do I fire it without a trigger lol?"
- Vampyro

"Huehuehue plan C."
- Rainfire5

"that is the single greatest steampunk rifle ever"
- Yoko_

"Why I always think I need a 3D Derpiwolf head ._."
- Kololz

"Wearing goggles over my head, armed with a Victorian-era revolver, and blasting creepers down one-handed? **** yes."
- HawttyHawk
